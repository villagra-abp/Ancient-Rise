#include "../headerfiles/TLuz.h"

TLuz::TLuz(){

}
TLuz::~TLuz(){

}
void TLuz::endDraw(){

}
void TLuz::beginDraw(){

}
