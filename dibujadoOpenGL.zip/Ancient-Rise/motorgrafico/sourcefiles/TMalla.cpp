#include "../headerfiles/TMalla.h"

TMalla::TMalla(){

}
TMalla::~TMalla(){

}
void TMalla::endDraw(){
	//malla->draw (...)
}
void TMalla::beginDraw(){

}

