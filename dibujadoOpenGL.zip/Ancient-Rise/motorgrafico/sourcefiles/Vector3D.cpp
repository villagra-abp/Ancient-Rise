#include "../headerfiles/Vector3D.h"




Vector3D::Vector3D(){
	X = 0;
	Y = 0;
	Z = 0;
}

Vector3D::Vector3D(float x, float y, float z){
	X = x;
	Y = y;
	Z = z;
}

Vector3D::~Vector3D(){

}
