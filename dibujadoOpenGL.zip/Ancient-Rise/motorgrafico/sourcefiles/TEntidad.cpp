#include "../headerfiles/TEntidad.h"

TEntidad::TEntidad(){

}
TEntidad::~TEntidad(){

}
