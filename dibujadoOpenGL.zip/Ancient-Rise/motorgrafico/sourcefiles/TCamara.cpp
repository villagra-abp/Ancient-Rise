#include "../headerfiles/TCamara.h"

TCamara::TCamara(){
	
}
TCamara::~TCamara(){

}
void setPerspectiva(){

}
void setParalela(){

}
void TCamara::endDraw(){

}
void TCamara::beginDraw(){

}


