#!/bin/bash

echo Ejecutando Ancient Rise

LD_LIBRARY_PATH=lib ./bin/AncientRise