#include <GL/gl.h>


int main(){
    unsigned int VBO;
	glGenBuffers(1,&VBO);
}
