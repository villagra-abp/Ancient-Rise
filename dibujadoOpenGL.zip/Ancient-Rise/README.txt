En este entregable se muestra lo que dibujamos por ahora con OpenGL. No se dibuja mucho, esto se debe en gran parte a los problemas para ejecutar OpenGL 3.3 (y superior) en el portatil del encargado.

Se dibujan 2 triángulos cada uno con un programa shader distinto.

Apretando Q o E se cambia el modo de visualización.

El ejecutable se ejecuta ejecutando el script "ejecutar.sh". Valgan las redundancias.
